#ifndef MARSYAS_MIDIDEVICES_H
#define MARSYAS_MIDIDEVICES_H




#define DEVIBOT_DHA 3
#define DEVIBOT_TU 2
#define DEVIBOT_GE 1
#define DEVIBOT_NA 0





#endif
